"""Adapted from https://github.com/jzbjyb/FLARE"""
