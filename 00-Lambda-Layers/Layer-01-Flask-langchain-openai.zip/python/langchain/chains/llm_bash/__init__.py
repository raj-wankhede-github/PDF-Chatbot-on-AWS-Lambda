"""Chain that interprets a prompt and executes bash code to perform bash operations."""
