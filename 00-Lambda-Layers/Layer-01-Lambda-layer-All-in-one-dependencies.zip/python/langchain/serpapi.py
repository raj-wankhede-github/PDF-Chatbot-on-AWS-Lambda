"""For backwards compatibility."""
from langchain.utilities.serpapi import SerpAPIWrapper

__all__ = ["SerpAPIWrapper"]
