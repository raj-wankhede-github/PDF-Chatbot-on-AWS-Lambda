"""Keep here for backwards compatibility."""
from langchain.utilities.sql_database import SQLDatabase

__all__ = ["SQLDatabase"]
