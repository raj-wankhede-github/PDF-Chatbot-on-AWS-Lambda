"""Shell tool."""

from langchain.tools.shell.tool import ShellTool

__all__ = ["ShellTool"]
