"""Google Scholar API Toolkit."""

from langchain.tools.google_scholar.tool import GoogleScholarQueryRun

__all__ = ["GoogleScholarQueryRun"]
