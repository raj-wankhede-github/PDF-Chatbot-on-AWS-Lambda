class LangChainException(Exception):
    """General LangChain exception."""
